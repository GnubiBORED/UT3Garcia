UT3 - PROYECTO
ENRIQUE GARCIA GRACIA -- egarciagra@educacion.navarra.es

Este repositorio es una practica de android, mediante la cual hemos creado una aplicacion 
con una interfaz sencilla , una aplicacion que ira desarrollandose a lo largo del curso.

He tenido alguna dificultad a la hora de entender como colorear los iconos por lo demas el tutorial
ha sido bastante intuitivo para crear la interfaz y todos sus elementos.

La aplicacion es multilingue en Ingles Español y euskera.

la aplicacion esta disponible en este repositorio con el proyecto entero de android studio.
